function TP=transitionprobandreward(maxcars,lambdarent,lambdareturn,rentreward)
TP=zeros([maxcars+1 maxcars+1 2]);
poisson=@(n,lambda)((lambda^n)/factorial(n))*exp(-lambda);
for curstate=0:maxcars %currentstate
    for transtate=0:maxcars %transitionstate
        for returned=0:maxcars %number of returned cars
            for rented=0:(curstate+returned) %number of rented cars which is limited by the number of available cars
%                 temptranstate=min(transtate,curstate+(returned-rented));
                if curstate+(returned-rented)==transtate %check if the combination of returned and returned cars gives the transtition state
                    returnp=poisson(returned,lambdareturn); 
                    rentp=poisson(rented,lambdarent);
                    TP(curstate+1,transtate+1,1)=TP(curstate+1,transtate+1,1)+returnp*rentp;
                    TP(curstate+1,transtate+1,2)=TP(curstate+1,transtate+1,2)+rentp*rentreward*rented;
                end
            end
        end
    end
end
% TP(:,:,2)=TP(:,:,2)-2*action;
end





