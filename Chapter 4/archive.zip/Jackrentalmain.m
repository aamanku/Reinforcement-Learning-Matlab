clear all
clc
%%
maxcars=20;
lambdarent1=3;
lambdaret1=3;
lambdarent2=4;
lambdaret2=2;
rewardrent=10;
rewardmove=-2;
maxmove=5;
discountrate=0.9;

%%
TP1=transitionprobandreward(maxcars,lambdarent1,lambdaret1,rewardrent);
TP2=transitionprobandreward(maxcars,lambdarent2,lambdaret2,rewardrent);
valuemat=zeros(maxcars+1);
policymat=0*ones(maxcars+1);
%%
iterpolicyimprove=0;
iterpolicyeval=0;
i=1;
while i==1
    i=0;
    while 1
        previousvaluemat=valuemat;
        for s1=0:maxcars
            for s2=0:maxcars
                amin=max(-maxmove,-s2);
                amax=min(maxmove,s1);
                best=[amin;valueeval(maxcars,rewardmove,discountrate,TP1,TP2, valuemat,s1,s2,amin)];
                for a=amin+1:amax
                    tempval=valueeval(maxcars,rewardmove,discountrate,TP1,TP2, valuemat,s1,s2,a);
                    if tempval>best(2)
                        best(1)=a;
                        best(2)=tempval;
                    end
                end
                valuemat(s1+1,s2+1)=best(2);
            end
        end
        [x,y]=meshgrid(0:20,0:20);
        surf(x,y,valuemat)
        % heatmap(valuemat);
        drawnow limitrate
        if max(max(abs(previousvaluemat-valuemat)))<0.01
            break;
        end
        iterpolicyeval=iterpolicyeval+1;
    end
    figure
    %%
    previouspolicymat=policymat;
    for s1=0:maxcars
        for s2=0:maxcars
            amin=max(-maxmove,-s2);
            amax=min(maxmove,s1);
            best=[amin;valueeval(maxcars,rewardmove,discountrate,TP1,TP2, valuemat,s1,s2,amin)];
            for a=amin+1:amax
                tempval=valueeval(maxcars,rewardmove,discountrate,TP1,TP2, valuemat,s1,s2,a);
                if tempval>best(2)
                    best(1)=a;
                    best(2)=tempval;
                end
                
            end
            policymat(s1+1,s2+1)=best(1);
        end
    end
    if max(abs(previouspolicymat-policymat))==0
        break;
    end
    iterpolicyimprove=iterpolicyimprove+1;
    [x,y]=meshgrid(0:20,0:20);
surf(x,y,policymat)
drawnow

end
[x,y]=meshgrid(0:20,0:20);
surf(x,y,policymat)

