clear 
a=rand(3000);
tic
for i=1:1
    e=max(a);
end
toc
tic
A=gpuArray(a);
for i=1:100000
    e=max(A);
end
toc
