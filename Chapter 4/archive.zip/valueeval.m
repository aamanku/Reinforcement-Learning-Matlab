function value=valueeval(maxcars,rewardmove,discountrate,TP1,TP2,valuemat,s1,s2,action)
value=valuemat(s1+1,s2+1);
a=action;
% a=min(a,s1);
% a=max(a,-s2);
s1=min(max(s1-a,0),maxcars);
s2=min(max(s2+a,0),maxcars);
% s1=min(s1-a,maxcars);
% s2=min(s2+a,maxcars);
% s1=s1-a;
% s2=s2+a;
if s2<0 || s1<0
         disp('yo')
    return;
else
    value=abs(a)*rewardmove;
    for sd1=0:maxcars
        for sd2=0:maxcars
            value=value+TP1(s1+1,sd1+1,1)*TP2(s2+1,sd2+1,1)*(TP1(s1+1,sd1+1,2)+TP2(s2+1,sd2+1,2)+discountrate*valuemat(sd1+1,sd2+1));
        end
    end
end
end
