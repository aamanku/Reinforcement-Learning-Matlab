function TP=transitionprob(maxcars,lambdarent,lambdareturn)
TP=zeros(maxcars+1);
poisson=@(n,lambda)((lambda^n)/factorial(n))*exp(-lambda);
for curstate=0:20 %currentstate
    for transtate=0:20 %transitionstate
        for returned=0:20 %number of returned cars
            for rented=0:(curstate+returned) %number of rented cars which is limited by the number of available cars
                if curstate+(returned-rented)==transtate %check if the combination of returned and returned cars gives the transtition state
                    returnp=poisson(returned,lambdareturn); 
                    rentp=poisson(rented,lambdarent);
                    TP(curstate+1,transtate+1)=TP(curstate+1,transtate+1)+returnp*rentp;
                end
            end
        end
    end
end




% for i=1:21
%     for j=1:21
%         for k=1:20
%             pd=1-poissrnd(lam1rent)+poissrnd(lam1ret)+j;
%             if pd>0 && pd<22
%                 P1(i,pd)=P1(i,pd)+1;
%             end
%         end
%     end
% end