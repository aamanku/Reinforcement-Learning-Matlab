function TP=transitionprobandreward(maxcars,lambdarent,lambdareturn,rentreward)
TP=zeros([maxcars+1 maxcars+1 2]);
poisson=@(n,lambda)((lambda^n)/factorial(n))*exp(-lambda);
for rented=0:maxcars
    for returned=0:maxcars
        returnp=poisson(returned,lambdareturn);
        rentp=poisson(rented,lambdarent);
        prob=returnp*rentp;
        reward=rented*rentreward;
        TP()
    end
end
end

% function TP=transitionprobandreward(maxcars,lambdarent,lambdareturn,rentreward)
% TP=zeros([maxcars+1 maxcars+1 2]);
% poisson=@(n,lambda)((lambda^n)/factorial(n))*exp(-lambda);
% for curstate=0:maxcars %currentstate
%     for transtate=0:maxcars %transitionstate
%
%         for rented=0:(curstate) %number of rented cars which is limited by the number of available cars
%             for returned=0:maxcars-(curstate-rented)*0 %number of returned cars
%                 %                 temptranstate=min(transtate,curstate+(returned-rented));
%                 if curstate+(returned-rented)==transtate %check if the combination of returned and returned cars gives the transtition state
%                     returnp=poisson(returned,lambdareturn);
%                     rentp=poisson(rented,lambdarent);
%                     TP(curstate+1,transtate+1,1)=TP(curstate+1,transtate+1,1)+returnp*rentp;
%                     TP(curstate+1,transtate+1,2)=TP(curstate+1,transtate+1,2)+rentp*rentreward*rented;
%                 end
%             end
%         end
%     end
% end
% TP(:,:,1)=(TP(:,:,1)'./sum(TP(:,:,1)'))';
% % TP(3:end,:,2)=(TP(3:end,:,2)'./sum(TP(3:end,:,2)'))'*rentreward;
% % TP(:,:,2)=TP(:,:,2)-2*action;
% end
%





